import React, { lazy, Suspense, useState, useEffect } from "react";
import { seedDatabase } from "@/lib/db";
import { initCrypto } from "@/lib/crypto";
import { migrateEncryption } from "@/lib/patientCrypto";
import { autoRestoreIfNeeded, installAutoSnapshotHooks, scheduleSnapshot } from "@/lib/emergencyBackup";
import { requestNotificationPermission, initSmartNotifications, stopSmartNotifications } from "@/lib/smartNotifications";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import { useServerSync } from "@/hooks/useServerSync";
import { LangProvider } from "@/contexts/LangContext";
import { LoginScreen } from "@/components/LoginScreen";
import { DashboardPage } from "@/components/DashboardPage";
import { ClinicOnboarding } from "@/components/ClinicOnboarding";
import { AppLayout, type Page } from "@/components/AppLayout";
import { isClinicConfigured } from "@/lib/clinicSettings";
import { db } from "@/lib/db";
import { toast } from "sonner";

const PatientsPage = lazy(() => import("@/components/PatientsPage").then(m => ({ default: m.PatientsPage })));
const AgendaPage = lazy(() => import("@/components/AgendaPage").then(m => ({ default: m.AgendaPage })));
const ConsultationsPage = lazy(() => import("@/components/ConsultationsPage").then(m => ({ default: m.ConsultationsPage })));
const DocumentsPage = lazy(() => import("@/components/DocumentsPage").then(m => ({ default: m.DocumentsPage })));
const DiagnosisPage = lazy(() => import("@/components/DiagnosisPage").then(m => ({ default: m.DiagnosisPage })));
const ResearchPage = lazy(() => import("@/components/ResearchPage").then(m => ({ default: m.ResearchPage })));
const PharmacyPage = lazy(() => import("@/components/PharmacyPage").then(m => ({ default: m.PharmacyPage })));
const MagasinPage = lazy(() => import("@/components/MagasinPage").then(m => ({ default: m.MagasinPage })));
const LabPage = lazy(() => import("@/components/LabPage").then(m => ({ default: m.LabPage })));
const MassConsultPage = lazy(() => import("@/components/MassConsultPage").then(m => ({ default: m.MassConsultPage })));
const VisitQuickPage = lazy(() => import("@/components/VisitQuickPage").then(m => ({ default: m.VisitQuickPage })));
const DentalExamPage = lazy(() => import("@/components/DentalExamPage").then(m => ({ default: m.DentalExamPage })));
const UsersPage = lazy(() => import("@/components/UsersPage").then(m => ({ default: m.UsersPage })));
const BackupPage = lazy(() => import("@/components/BackupPage").then(m => ({ default: m.BackupPage })));
const AuditLogPage = lazy(() => import("@/components/AuditLogPage").then(m => ({ default: m.AuditLogPage })));
const SecurityPage = lazy(() => import("@/components/SecurityPage").then(m => ({ default: m.SecurityPage })));
const ClinicSettingsPage = lazy(() => import("@/components/ClinicSettingsPage").then(m => ({ default: m.ClinicSettingsPage })));
const WorkspacePage = lazy(() => import("@/components/WorkspacePage").then(m => ({ default: m.WorkspacePage })));
const PaymentsPage = lazy(() => import("@/components/PaymentsPage").then(m => ({ default: m.PaymentsPage })));
const EquipmentPage = lazy(() => import("@/components/EquipmentPage").then(m => ({ default: m.EquipmentPage })));
const ObservationTemplatesPage = lazy(() => import("@/components/ObservationTemplatesPage").then(m => ({ default: m.ObservationTemplatesPage })));
const ImportPatientsPage = lazy(() => import("@/components/ImportPatientsPage").then(m => ({ default: m.ImportPatientsPage })));
const ScheduledSyncPage = lazy(() => import("@/components/ScheduledSyncPage").then(m => ({ default: m.ScheduledSyncPage })));
const SyncConflictsPage = lazy(() => import("@/components/SyncConflictsPage").then(m => ({ default: m.SyncConflictsPage })));
const SurveysPage = lazy(() => import("@/components/SurveysPage").then(m => ({ default: m.SurveysPage })));
const SpecialtySettingsPage = lazy(() => import("@/components/SpecialtySettingsPage").then(m => ({ default: m.SpecialtySettingsPage })));
const StaffPage = lazy(() => import("@/components/StaffPage").then(m => ({ default: m.StaffPage })));
const MySpacePage = lazy(() => import("@/components/MySpacePage").then(m => ({ default: m.MySpacePage })));
const DocumentCategoriesPage = lazy(() => import("@/components/DocumentCategoriesPage").then(m => ({ default: m.DocumentCategoriesPage })));
const AdmissionsPage = lazy(() => import("@/components/AdmissionsPage").then(m => ({ default: m.AdmissionsPage })));
const ExpeditionsPage = lazy(() => import("@/components/ExpeditionsPage").then(m => ({ default: m.ExpeditionsPage })));
const MinsanteReport = lazy(() => import("@/components/MinsanteReport").then(m => ({ default: m.MinsanteReport })));
const ProfitReport = lazy(() => import("@/components/ProfitReport").then(m => ({ default: m.ProfitReport })));

function PageLoader() {
  return (
    <div className="flex items-center justify-center h-64">
      <div className="flex flex-col items-center gap-3">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
        <p className="text-sm text-muted-foreground">Chargement...</p>
      </div>
    </div>
  );
}

function AppContent() {
  const { user } = useAuth();
  useServerSync(5, !!user);
  const [page, setPage] = useState<Page>(() => {
    const saved = sessionStorage.getItem("divinelink.currentPage") as Page | null;
    return saved || "dashboard";
  });

  const navigateTo = (p: Page) => {
    sessionStorage.setItem("divinelink.currentPage", p);
    setPage(p);
  };
  const [showOnboarding, setShowOnboarding] = useState(false);

  useEffect(() => {
    if (user && !isClinicConfigured()) setShowOnboarding(true);
  }, [user]);

  useEffect(() => {
    if (user) {
      initSmartNotifications(user.name);
      import("@/lib/appointmentAlarms").then(m => m.startAppointmentAlarms());
    }
    return () => {
      stopSmartNotifications();
      import("@/lib/appointmentAlarms").then(m => m.stopAppointmentAlarms());
    };
  }, [user]);

  // Check for missed reminders on app open
  useEffect(() => {
    if (!user) return;
    (async () => {
      try {
        const now = new Date().toISOString().split("T")[0];
        const twoDaysAgo = new Date(Date.now() - 2 * 86400000).toISOString().split("T")[0];
        const appointments = await db.appointments.toArray();
        const missed = appointments.filter(a => a.date >= twoDaysAgo && a.date < now && a.status === "scheduled");
        if (missed.length > 0) {
          toast.warning(`${missed.length} rendez-vous manqu(s) — consultez les rappels`, { duration: 8000 });
        }
      } catch {}
    })();
  }, [user]);

  if (!user) return <LoginScreen />;

  const isAdmin = user.role === "admin";
  const adminOnly = (node: React.ReactNode): React.ReactNode =>
    isAdmin ? node : <DashboardPage onNavigate={navigateTo} />;

  const pages: Record<Page, React.ReactNode> = {
    dashboard: <DashboardPage onNavigate={navigateTo} />,
    patients: <Suspense fallback={<PageLoader />}><PatientsPage /></Suspense>,
    appointments: <Suspense fallback={<PageLoader />}><AgendaPage /></Suspense>,
    consultations: <Suspense fallback={<PageLoader />}><ConsultationsPage /></Suspense>,
    documents: <Suspense fallback={<PageLoader />}><DocumentsPage /></Suspense>,
    diagnosis: <Suspense fallback={<PageLoader />}><DiagnosisPage /></Suspense>,
    users: adminOnly(<Suspense fallback={<PageLoader />}><UsersPage /></Suspense>),
    backup: adminOnly(<Suspense fallback={<PageLoader />}><BackupPage /></Suspense>),
    audit: adminOnly(<Suspense fallback={<PageLoader />}><AuditLogPage /></Suspense>),
    security: adminOnly(<Suspense fallback={<PageLoader />}><SecurityPage /></Suspense>),
    research: <Suspense fallback={<PageLoader />}><ResearchPage /></Suspense>,
    minsante: <Suspense fallback={<PageLoader />}><MinsanteReport /></Suspense>,
    expeditions: <Suspense fallback={<PageLoader />}><ExpeditionsPage /></Suspense>,
    clinic: <Suspense fallback={<PageLoader />}><ClinicSettingsPage /></Suspense>,
    pharmacy: <Suspense fallback={<PageLoader />}><PharmacyPage /></Suspense>,
    magasin: <Suspense fallback={<PageLoader />}><MagasinPage /></Suspense>,
    lab: <Suspense fallback={<PageLoader />}><LabPage /></Suspense>,
    massconsult: <Suspense fallback={<PageLoader />}><MassConsultPage /></Suspense>,
    visit: <Suspense fallback={<PageLoader />}><VisitQuickPage /></Suspense>,

    workspace: <Suspense fallback={<PageLoader />}><WorkspacePage /></Suspense>,
    payments: <Suspense fallback={<PageLoader />}><PaymentsPage /></Suspense>,
    profits: <Suspense fallback={<PageLoader />}><ProfitReport /></Suspense>,
    equipment: <Suspense fallback={<PageLoader />}><EquipmentPage /></Suspense>,
    templates: adminOnly(<Suspense fallback={<PageLoader />}><ObservationTemplatesPage /></Suspense>),
    importPatients: adminOnly(<Suspense fallback={<PageLoader />}><ImportPatientsPage /></Suspense>),
    sync: adminOnly(<Suspense fallback={<PageLoader />}><ScheduledSyncPage /></Suspense>),
    conflicts: adminOnly(<Suspense fallback={<PageLoader />}><SyncConflictsPage /></Suspense>),
    surveys: <Suspense fallback={<PageLoader />}><SurveysPage /></Suspense>,
    specialties: adminOnly(<Suspense fallback={<PageLoader />}><SpecialtySettingsPage /></Suspense>),
    staff: <Suspense fallback={<PageLoader />}><StaffPage /></Suspense>,
    myspace: <Suspense fallback={<PageLoader />}><MySpacePage /></Suspense>,
    docCategories: adminOnly(<Suspense fallback={<PageLoader />}><DocumentCategoriesPage /></Suspense>),
    admissions: <Suspense fallback={<PageLoader />}><AdmissionsPage /></Suspense>,
  };

  return (
    <>
      <AppLayout currentPage={page} onNavigate={navigateTo}>
        {pages[page]}
      </AppLayout>
      <ClinicOnboarding open={showOnboarding} onDone={() => setShowOnboarding(false)} />
    </>
  );
}

const Index = () => {
  useEffect(() => {
    requestNotificationPermission();
    (async () => {
      await initCrypto();
      // Try silent restore BEFORE seeding so we don't overwrite a recovered admin.
      await autoRestoreIfNeeded();
      await seedDatabase();
      await migrateEncryption();
      installAutoSnapshotHooks();
      // Take an initial snapshot once everything is ready.
      scheduleSnapshot();
    })();
  }, []);

  return (
    <LangProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </LangProvider>
  );
};

export default Index;
