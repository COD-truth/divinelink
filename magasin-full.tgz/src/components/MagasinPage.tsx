import { useEffect, useMemo, useState } from "react";
import { db, type Drug, type EquipmentItem } from "@/lib/db";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Warehouse, Search, ArrowRight, PackagePlus, Pill, Wrench, TriangleAlert } from "lucide-react";
import { toast } from "sonner";

type Kind = "drug" | "equip";
interface Row {
  kind: Kind; id: number; name: string; unit: string; type: string;
  magasin: number; subset: number; subsetLabel: string; minMag: number;
}

export function MagasinPage() {
  const { user } = useAuth();
  const [drugs, setDrugs] = useState<Drug[]>([]);
  const [equip, setEquip] = useState<EquipmentItem[]>([]);
  const [search, setSearch] = useState("");
  const [action, setAction] = useState<{ row: Row; mode: "receive" | "transfer" } | null>(null);
  const [qtyStr, setQtyStr] = useState("");
  const [busy, setBusy] = useState(false);

  const load = async () => {
    const active = localStorage.getItem("divinelink.clinicId");
    const inClinic = (c?: string) => !active || !c || String(c) === String(active);
    setDrugs((await db.drugs.toArray()).filter(d => inClinic(d.clinicId)));
    setEquip((await db.equipmentItems.toArray()).filter(e => inClinic(e.clinicId)));
  };
  useEffect(() => { load(); }, []);

  const rows: Row[] = useMemo(() => {
    const r: Row[] = [];
    drugs.forEach(d => r.push({ kind: "drug", id: d.id!, name: d.name, unit: d.unit || "u", type: d.category || "Médicament", magasin: d.stockMagasin ?? 0, subset: d.stock ?? 0, subsetLabel: "Comptoir", minMag: d.minStockMagasin ?? 0 }));
    equip.forEach(e => r.push({ kind: "equip", id: e.id!, name: e.name, unit: e.unit || "u", type: "Équipement", magasin: e.stockMagasin ?? 0, subset: e.stock ?? 0, subsetLabel: "En service", minMag: e.minStockMagasin ?? 0 }));
    const q = search.trim().toLowerCase();
    return r.filter(x => !q || x.name.toLowerCase().includes(q) || x.type.toLowerCase().includes(q)).sort((a, b) => a.name.localeCompare(b.name));
  }, [drugs, equip, search]);

  const lowCount = rows.filter(x => x.minMag > 0 && x.magasin <= x.minMag).length;
  const openAction = (row: Row, mode: "receive" | "transfer") => { setAction({ row, mode }); setQtyStr(""); };

  const doAction = async () => {
    if (!action) return;
    const qty = Math.max(0, parseInt(qtyStr) || 0);
    if (qty <= 0) { toast.error("Quantité invalide"); return; }
    const { row, mode } = action;
    if (mode === "transfer" && qty > row.magasin) { toast.error("Pas assez au magasin"); return; }
    setBusy(true);
    try {
      const now = new Date().toISOString();
      const cid = localStorage.getItem("divinelink.clinicId") || undefined;
      if (row.kind === "drug") {
        const d = await db.drugs.get(row.id); if (!d) return;
        if (mode === "receive") {
          await db.drugs.update(row.id, { stockMagasin: (d.stockMagasin ?? 0) + qty, updatedAt: now });
        } else {
          await db.drugs.update(row.id, { stockMagasin: (d.stockMagasin ?? 0) - qty, stock: (d.stock ?? 0) + qty, updatedAt: now });
          await db.drugTransactions.add({ drugId: row.id, type: "in", quantity: qty, price: 0, exitReason: "transferred", performedBy: user?.name, clinicId: cid, createdAt: now } as any);
        }
      } else {
        const e = await db.equipmentItems.get(row.id); if (!e) return;
        if (mode === "receive") {
          await db.equipmentItems.update(row.id, { stockMagasin: (e.stockMagasin ?? 0) + qty, updatedAt: now });
        } else {
          const newStock = (e.stock ?? 0) + qty;
          await db.equipmentItems.update(row.id, { stockMagasin: (e.stockMagasin ?? 0) - qty, stock: newStock, updatedAt: now });
          await db.equipmentMovements.add({ itemId: row.id, itemName: row.name, quantityChange: qty, newStock, reason: "Transfert magasin → poste", userName: user?.name || "", clinicId: cid, createdAt: now } as any);
        }
      }
      toast.success(mode === "receive" ? `+${qty} ajouté au magasin` : `${qty} transféré vers ${row.subsetLabel.toLowerCase()}`);
      setAction(null);
      await load();
    } catch (err: any) {
      toast.error("Erreur: " + (err?.message || "échec"));
    } finally { setBusy(false); }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <h1 className="text-xl font-bold flex items-center gap-2"><Warehouse className="w-5 h-5" /> Magasin</h1>
        <p className="text-xs text-muted-foreground">Réserve centrale — la pharmacie et l'équipement en sont des sous-ensembles.</p>
      </div>

      {lowCount > 0 && (
        <Card className="border-warning/50 bg-warning/5">
          <CardContent className="p-3 flex items-center gap-2 text-sm">
            <TriangleAlert className="w-4 h-4 text-warning" /> {lowCount} article(s) en réserve basse au magasin.
          </CardContent>
        </Card>
      )}

      <div className="relative">
        <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
        <Input className="pl-9" placeholder="Rechercher un article…" value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      <div className="space-y-2">
        {rows.length === 0 && <p className="text-sm text-muted-foreground">Aucun article. Ajoutez-les depuis Pharmacie ou Équipement, puis gérez le stock ici.</p>}
        {rows.map(row => {
          const low = row.minMag > 0 && row.magasin <= row.minMag;
          return (
            <Card key={`${row.kind}-${row.id}`}>
              <CardContent className="p-3 flex items-center gap-3">
                {row.kind === "drug" ? <Pill className="w-4 h-4 text-primary flex-shrink-0" /> : <Wrench className="w-4 h-4 text-muted-foreground flex-shrink-0" />}
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">{row.name}</p>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Badge variant="outline" className="text-[10px]">{row.type}</Badge>
                    <span>{row.subsetLabel}: <b>{row.subset}</b></span>
                  </div>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-[10px] text-muted-foreground">Magasin</p>
                  <p className={`text-xl font-bold leading-none ${low ? "text-warning" : ""}`}>{row.magasin}</p>
                </div>
                <div className="flex flex-col gap-1 flex-shrink-0">
                  <Button size="sm" variant="outline" className="h-7 gap-1 text-xs" onClick={() => openAction(row, "receive")}>
                    <PackagePlus className="w-3.5 h-3.5" /> Entrée
                  </Button>
                  <Button size="sm" className="h-7 gap-1 text-xs" disabled={row.magasin <= 0} onClick={() => openAction(row, "transfer")}>
                    <ArrowRight className="w-3.5 h-3.5" /> Transférer
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Dialog open={!!action} onOpenChange={v => { if (!v) setAction(null); }}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>
              {action?.mode === "receive" ? "Entrée en magasin" : `Transfert → ${action?.row.subsetLabel}`} — {action?.row.name}
            </DialogTitle>
          </DialogHeader>
          {action && (
            <div className="space-y-3">
              <div className="flex items-center justify-around rounded-lg border p-3 text-center">
                <div><p className="text-xs text-muted-foreground">Magasin</p><p className="text-2xl font-bold">{action.row.magasin}</p></div>
                {action.mode === "transfer" && <><ArrowRight className="w-6 h-6 text-primary" /><div><p className="text-xs text-muted-foreground">{action.row.subsetLabel}</p><p className="text-2xl font-bold">{action.row.subset}</p></div></>}
              </div>
              <div>
                <label className="text-sm font-medium">Quantité ({action.row.unit})</label>
                <Input type="number" min={1} value={qtyStr} onChange={e => setQtyStr(e.target.value)} autoFocus />
              </div>
            </div>
          )}
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setAction(null)} disabled={busy}>Annuler</Button>
            <Button onClick={doAction} disabled={busy}>{action?.mode === "receive" ? "Ajouter" : "Transférer"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
