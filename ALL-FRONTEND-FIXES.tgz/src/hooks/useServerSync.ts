import { useCallback, useEffect, useRef } from "react";
import { db } from "@/lib/db";
import { api } from "@/lib/api";

// Demo-safe: do NOT pull server data down onto devices. Each device shows only
// what was entered on it (data still pushes UP to the server as backup). This
// prevents any stale/foreign server data from ever appearing on a device.
// Multi-device pull is part of the proper sync rework — turn on by setting
// localStorage "dl.pullEnabled" = "1".
const ENABLE_SERVER_PULL = false;
function pullEnabled(): boolean {
  try { return ENABLE_SERVER_PULL || localStorage.getItem("dl.pullEnabled") === "1"; } catch { return ENABLE_SERVER_PULL; }
}

export function useServerSync(intervalMinutes = 5, enabled = true) {
  const syncRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const syncNow = useCallback(async () => {
    if (!navigator.onLine) return;
    if (!localStorage.getItem("divinelink.apiToken")) return;

    try {
      // ── Clinic isolation guard ──
      // Only ever push records that belong to the clinic this device is linked
      // to right now. Without this, a device that holds another clinic's data
      // would upload it into the active clinic on the server.
      const activeClinic = localStorage.getItem("divinelink.clinicId");
      if (!activeClinic) { console.warn("[sync] no active clinic — skipping push"); return; }
      // Untagged records belong to this device's current clinic — adopt them.
      try {
        await db.patients.filter(p => !p.clinicId).modify({ clinicId: activeClinic });
        await db.consultations.filter(c => !c.clinicId).modify({ clinicId: activeClinic });
        await db.documents.filter(d => !d.clinicId).modify({ clinicId: activeClinic });
      } catch { /* ignore */ }
      const belongs = (rec: { clinicId?: string }) => String(rec.clinicId) === activeClinic;

      // ══ PATIENTS SYNC v2 — uid-keyed · delta · tombstone-aware · plaintext boundary ══
      const API_BASE = "https://divinelink.mooo.com/api";
      const authToken = localStorage.getItem("divinelink.apiToken");
      const authHeaders: Record<string, string> = { "Content-Type": "application/json", Authorization: `Bearer ${authToken}` };
      const { decryptStringSafe, encryptString, isCiphertext } = await import("@/lib/crypto");
      const patLastKey = `dl.lastSync.patients.${activeClinic}`;
      const patSince = localStorage.getItem(patLastKey) || "1970-01-01T00:00:00.000Z";
      let patCursor = patSince;

      // Build a server body from a local patient, DECRYPTING sensitive fields to
      // plaintext. Returns null when any non-empty sensitive field is unreadable
      // ciphertext — a foreign/old row this device's key cannot decode, which we
      // must NEVER publish (that is what spread garbage across devices before).
      const buildPatientBody = async (p: any): Promise<any | null> => {
        const ph = await decryptStringSafe(p.phone || "");
        const ad = await decryptStringSafe(p.address || "");
        const ma = await decryptStringSafe(p.medicalAlerts || "");
        if (!ph.readable || !ad.readable || !ma.readable) return null;
        return {
          uid: p.uid,
          patient_code: p.patientId,
          first_name: p.firstName,
          last_name: p.lastName,
          phone: ph.text,
          date_of_birth: p.dob || null,
          address: ad.text,
          medical_alerts: ma.text,
          registered_by: p.registeredBy || null,
          registered_at: p.registeredAt || null,
          visit_type: p.visitType || null,
          reason_for_visit: p.reasonForVisit || null,
          deleted: !!p.deleted,
          updated_at: p.updatedAt,
        };
      };

      // PUSH: this clinic's patients changed since last sync. Sensitive fields
      // are DECRYPTED here so the server (and every other device) gets plaintext.
      const patChanged = (await db.patients.toArray())
        .filter(p => belongs(p) && p.uid && String(p.updatedAt || "") > patSince);
      for (const p of patChanged) {
        try {
          const body = await buildPatientBody(p);
          if (!body) continue; // unreadable foreign row — never push garbage
          if (String(p.updatedAt || "") > patCursor) patCursor = String(p.updatedAt);
          await fetch(`${API_BASE}/patients`, { method: "POST", headers: authHeaders, body: JSON.stringify(body) });
        } catch { /* best-effort */ }
      }

      // ── HEAL (one-time per clinic) ──
      // Republish, as clean plaintext, every record THIS device can actually
      // read but that is still stored as ciphertext. After each clinic device
      // runs this once, the server holds real text for every recoverable record
      // and all devices display them correctly. Rows no device can read stay
      // hidden (shown as "—") until re-entered.
      const healKey = `dl.heal.plaintext.v2.${activeClinic}`;
      if (!localStorage.getItem(healKey)) {
        try {
          const nowIso = new Date().toISOString();
          const all = (await db.patients.toArray()).filter(p => belongs(p) && p.uid);
          let healed = 0;
          for (const p of all) {
            const hadCipher = isCiphertext(p.phone) || isCiphertext(p.address) || isCiphertext(p.medicalAlerts);
            if (!hadCipher) continue;
            const body = await buildPatientBody(p);
            if (!body) continue; // can't read it → leave it for its origin device
            body.updated_at = nowIso; // bump so last-write-wins republishes to all devices
            await fetch(`${API_BASE}/patients`, { method: "POST", headers: authHeaders, body: JSON.stringify(body) });
            healed++;
          }
          localStorage.setItem(healKey, "1");
          if (healed) console.log("[sync] healed plaintext for", healed, "patients");
        } catch (e) { console.warn("[sync] heal failed", e); }
      }

      // Sync consultations (ONLY this clinic's)
      const consultations = (await db.consultations
        .filter(c => c.isLatest !== false)
        .toArray()).filter(belongs);
      for (const c of consultations) {
        try {
          // look up the patient's CODE from their numeric id so it matches on the server
          const cPatient = await db.patients.get(c.patientId);
          const patientCode = cPatient?.patientId || String(c.patientId);
          await api.saveConsultation({
            patient_id: patientCode,
            local_id: c.id,
            specialty: c.consultType || "general",
            chief_complaint: c.chiefComplaint || c.symptoms,
            diagnosis: c.diagnosis,
            treatment: c.treatmentPlan,
            vital_signs: c.vitals || {},
          });
        } catch {}
      }

      // Sync documents (ONLY this clinic's)
      const documents = (await db.documents.toArray()).filter(belongs);
      for (const d of documents) {
        try {
          await api.saveDocument({
            patient_id: d.patientId,
            name: d.name,
            mime_type: d.type,
            data: d.data,
            size: d.size,
            tag: d.tag,
            consult_id: d.consultId ?? null,
          });
        } catch {}
      }

      // Sync survey responses (best-effort, marks synced=true on success)
      try {
        const unsynced = await db.surveyResponses.filter(r => !r.synced).toArray();
        for (const r of unsynced) {
          try {
            const survey = await db.surveys.get(r.surveyId);
            if (!survey) continue;
            const res = await fetch(`${(window as any).__DIVINELINK_API_BASE__ || "https://divinelink.mooo.com/api"}/surveys/${survey.serverId || survey.inviteCode}/responses`, {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                ...(localStorage.getItem("divinelink.apiToken") ? { Authorization: `Bearer ${localStorage.getItem("divinelink.apiToken")}` } : {}),
              },
              body: JSON.stringify({
                respondent_name: r.respondentName,
                respondent_phone: r.respondentPhone,
                answers: r.answers,
                started_at: r.startedAt,
                completed_at: r.completedAt,
              }),
            });
            if (res.ok) {
              await db.surveyResponses.update(r.id!, { synced: true, syncedAt: new Date().toISOString() });
              // Upload voice blobs for this response
              const voices = await db.voiceRecordings.where("responseId").equals(r.id!).toArray();
              for (const v of voices.filter(vv => !vv.synced)) {
                try {
                  const fd = new FormData();
                  fd.append("audio", v.blob, `${v.questionId}.webm`);
                  fd.append("transcript", v.transcript || "");
                  const vres = await fetch(`${(window as any).__DIVINELINK_API_BASE__ || "https://divinelink.mooo.com/api"}/surveys/${survey.serverId || survey.inviteCode}/responses/${r.id}/voices/${v.questionId}`, {
                    method: "POST",
                    headers: localStorage.getItem("divinelink.apiToken") ? { Authorization: `Bearer ${localStorage.getItem("divinelink.apiToken")}` } : {},
                    body: fd,
                  });
                  if (vres.ok) await db.voiceRecordings.update(v.id!, { synced: true });
                } catch {}
              }
            }
          } catch {}
        }
      } catch {}
      // PULL: apply the server's patient rows (delta, INCLUDING tombstones), keyed
      // by uid. Sensitive fields arrive plaintext and are RE-ENCRYPTED with this
      // device's own key so they display correctly here. Last-write-wins.
      try {
        const res = await fetch(`${API_BASE}/patients?since=${encodeURIComponent(patSince)}`, { headers: authHeaders });
        if (res.ok) {
          const rows = await res.json();
          for (const sp of rows) {
            if (!sp.uid) continue;
            if (String(sp.updated_at || "") > patCursor) patCursor = String(sp.updated_at);
            const existing = await db.patients.where("uid").equals(sp.uid).first();
            if (sp.deleted) {
              if (existing?.id && !existing.deleted) await db.patients.update(existing.id, { deleted: true, updatedAt: sp.updated_at || new Date().toISOString() });
              continue;
            }
            const fields: any = {
              patientId: sp.patient_code,
              firstName: sp.first_name || "",
              lastName: sp.last_name || "",
              dob: sp.date_of_birth || "",
              registeredBy: sp.registered_by || undefined,
              registeredAt: sp.registered_at || undefined,
              visitType: sp.visit_type || undefined,
              reasonForVisit: sp.reason_for_visit || undefined,
              clinicId: activeClinic,
              uid: sp.uid,
              deleted: false,
              updatedAt: sp.updated_at || new Date().toISOString(),
            };
            // Only accept sensitive fields that arrive as PLAINTEXT. If the server
            // still holds old ciphertext (unhealed row), skip it so we never
            // overwrite a good local value with unreadable data, and re-encrypt
            // plaintext with THIS device's key so it displays here.
            if (!isCiphertext(sp.phone)) fields.phone = await encryptString(sp.phone || "");
            if (!isCiphertext(sp.address)) fields.address = await encryptString(sp.address || "");
            if (!isCiphertext(sp.medical_alerts)) fields.medicalAlerts = await encryptString(sp.medical_alerts || "");
            if (existing?.id) {
              if (String(sp.updated_at || "") >= String(existing.updatedAt || "")) await db.patients.update(existing.id, fields);
            } else {
              await db.patients.add({ ...fields, createdAt: sp.created_at || new Date().toISOString() });
            }
          }
          console.log("[sync] patients v2 applied:", rows.length);
        }
        localStorage.setItem(patLastKey, patCursor);
      } catch (e) { console.warn("[sync] patient pull v2 failed", e); }
      // PULL: download consultations from server that this device doesn't have
      if (pullEnabled()) try {
        const token = localStorage.getItem("divinelink.apiToken");
        const res = await fetch("https://divinelink.mooo.com/api/consultations", {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const serverConsults = await res.json();
          for (const sc of serverConsults) {
            // map server patient code -> local patient numeric id
            const patient = await db.patients.where("patientId").equals(sc.patient_id).first();
            const localPatientId = patient?.id ?? null;
            // avoid duplicates: skip if a consultation with same diagnosis+patient already exists
            const dup = await db.consultations
              .where("patientId").equals(localPatientId ?? -1)
              .filter(c => c.diagnosis === (sc.diagnosis || "") && c.symptoms === (sc.chief_complaint || ""))
              .first();
            if (!dup && localPatientId !== null) {
              await db.consultations.add({
                patientId: localPatientId,
                doctorId: 0,
                date: sc.created_at || new Date().toISOString(),
                symptoms: sc.chief_complaint || "",
                diagnosis: sc.diagnosis || "",
                treatmentPlan: sc.treatment || "",
                prescription: "",
                notes: "",
                consultType: sc.specialty || "general",
                clinicId: activeClinic,
                createdAt: sc.created_at || new Date().toISOString(),
                isLatest: true,
              });
            }
          }
          console.log("Pulled", serverConsults.length, "consultations from server");
        }
      } catch (e) { console.warn("Consultation pull failed", e); }
      try { localStorage.setItem("dl.lastSyncAt", String(Date.now())); } catch {}
      console.log("Server sync completed:", new Date().toISOString());
    } catch (err) {
      console.error("Server sync failed:", err);
    }
  }, []);

  useEffect(() => {
    if (!enabled) return;
    syncNow();
    syncRef.current = setInterval(syncNow, intervalMinutes * 60 * 1000);
    return () => {
      if (syncRef.current) clearInterval(syncRef.current);
    };
  }, [enabled, intervalMinutes, syncNow]);

  return { syncNow };
}