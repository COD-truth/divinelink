import { useEffect, useMemo, useState } from "react";
import { db, type Patient, type LabResult, type LabReagent } from "@/lib/db";
import { decryptPatients } from "@/lib/patientCrypto";
import { useAuth } from "@/contexts/AuthContext";
import { useLang } from "@/contexts/LangContext";
import { LAB_CATALOGUE } from "./LabResultsPage";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FlaskConical, Search, Plus, Trash2, FileText, FlaskRound } from "lucide-react";
import { toast } from "sonner";
import { logAudit } from "@/lib/audit";
import { LabReagents } from "./LabReagents";

const DICT = {
  fr: {
    title: "Laboratoire", newOrder: "Nouvelle demande", analyses: "Analyses", reagents: "Réactifs",
    pending: "En attente", done: "Terminés", all: "Tous", searchPh: "Rechercher patient ou examen…",
    none: "Aucune analyse.", enter: "Saisir", view: "Voir", newOrderTitle: "Nouvelle demande d'analyse",
    patient: "Patient", choose: "Choisir…", exam: "Examen", chooseExam: "Choisir un examen…",
    cancel: "Annuler", create: "Créer la demande", notes: "Notes / interprétation…",
    close: "Fermer", update: "Mettre à jour", save: "Enregistrer le résultat",
    needBoth: "Patient et examen requis", created: "Demande créée", saved: "Résultat enregistré",
    doneBadge: "Terminé", pendingBadge: "En attente",
    customExam: "➕ Autre analyse (préciser)", customName: "Nom de l'analyse", customNameReq: "Nom de l'analyse requis",
    freeResultPh: "Résultat / compte-rendu…", reagentsUsed: "Réactifs utilisés (déduit du stock)",
    addReagent: "Ajouter un réactif", qty: "Qté", pickReagent: "Choisir un réactif…", noReagents: "Aucun réactif en stock. Ajoutez-en dans l'onglet Réactifs.",
  },
  en: {
    title: "Laboratory", newOrder: "New request", analyses: "Analyses", reagents: "Reagents",
    pending: "Pending", done: "Completed", all: "All", searchPh: "Search patient or exam…",
    none: "No analyses.", enter: "Enter", view: "View", newOrderTitle: "New analysis request",
    patient: "Patient", choose: "Select…", exam: "Exam", chooseExam: "Select an exam…",
    cancel: "Cancel", create: "Create request", notes: "Notes / interpretation…",
    close: "Close", update: "Update", save: "Save result",
    needBoth: "Patient and exam required", created: "Request created", saved: "Result saved",
    doneBadge: "Completed", pendingBadge: "Pending",
    customExam: "➕ Other analysis (specify)", customName: "Analysis name", customNameReq: "Analysis name required",
    freeResultPh: "Result / report…", reagentsUsed: "Reagents used (deducted from stock)",
    addReagent: "Add a reagent", qty: "Qty", pickReagent: "Select a reagent…", noReagents: "No reagent in stock. Add some in the Reagents tab.",
  },
};

const ALL_EXAMS = LAB_CATALOGUE.flatMap((c: any) => c.exams.map((e: any) => ({ ...e, category: c.category })));
const examById = (id: string) => ALL_EXAMS.find((e: any) => e.id === id);

export function LabPage() {
  const { user } = useAuth();
  const { lang } = useLang();
  const L = DICT[lang] || DICT.fr;
  const cid = () => localStorage.getItem("divinelink.clinicId") || undefined;
  const inClinic = (c?: string) => { const a = cid(); return !a || !c || String(c) === String(a); };
  const [patients, setPatients] = useState<Patient[]>([]);
  const [rows, setRows] = useState<LabResult[]>([]);
  const [view, setView] = useState<"results" | "reagents">("results");
  const [tab, setTab] = useState("ordered");
  const [search, setSearch] = useState("");
  const [orderOpen, setOrderOpen] = useState(false);
  const [orderPatient, setOrderPatient] = useState("");
  const [orderExam, setOrderExam] = useState("");
  const [customName, setCustomName] = useState("");
  const [result, setResult] = useState<LabResult | null>(null);
  const [values, setValues] = useState<Record<string, string>>({});
  const [notes, setNotes] = useState("");
  const [freeResult, setFreeResult] = useState("");
  const [reagents, setReagents] = useState<LabReagent[]>([]);
  const [used, setUsed] = useState<{ reagentId: number; name: string; qty: number }[]>([]);
  const [busy, setBusy] = useState(false);

  const load = async () => {
    setPatients((await decryptPatients(await db.patients.toArray())).filter(p => !p.deleted && inClinic(p.clinicId)));
    setRows((await db.labResults.toArray()).filter(r => !r.deleted && inClinic(r.clinicId)).sort((a, b) => (b.orderedAt || "").localeCompare(a.orderedAt || "")));
    setReagents((await db.labReagents.toArray()).filter(r => inClinic(r.clinicId)).sort((a, b) => a.name.localeCompare(b.name)));
  };
  useEffect(() => { load(); }, []);

  const pName = (id: number) => { const p = patients.find(x => x.id === id); return p ? `${p.firstName} ${p.lastName}` : "—"; };
  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return rows.filter(r => (tab === "all" || r.status === tab) && (!q || pName(r.patientId).toLowerCase().includes(q) || r.examName.toLowerCase().includes(q)));
  }, [rows, tab, search, patients]);
  const orderedCount = rows.filter(r => r.status === "ordered").length;
  const doneCount = rows.filter(r => r.status === "completed").length;

  const createOrder = async () => {
    if (!orderPatient || !orderExam) { toast.error(L.needBoth); return; }
    const isCustom = orderExam === "__custom__";
    if (isCustom && !customName.trim()) { toast.error(L.customNameReq); return; }
    const exam = isCustom ? null : examById(orderExam);
    if (!isCustom && !exam) return;
    const examId = isCustom ? "custom" : exam.id;
    const examName = isCustom ? customName.trim() : exam.name;
    const category = isCustom ? "Autre" : exam.category;
    const now = new Date().toISOString();
    await db.labResults.add({
      uid: (globalThis.crypto?.randomUUID?.() || String(Date.now())),
      patientId: Number(orderPatient), examId, examName, category,
      status: "ordered", orderedBy: user?.name, orderedAt: now, clinicId: cid(), createdAt: now, updatedAt: now,
    } as any);
    await logAudit("lab_order", user?.name || "—", { resource: "lab", resourceId: examId, message: `${examName} · ${pName(Number(orderPatient))}` });
    toast.success(L.created);
    setOrderOpen(false); setOrderPatient(""); setOrderExam(""); setCustomName(""); await load();
  };

  const openResult = (r: LabResult) => { setResult(r); setValues(r.values || {}); setNotes(r.notes || ""); setFreeResult(r.freeResult || ""); setUsed(r.reagentsUsed || []); };
  const saveResult = async () => {
    if (!result) return;
    setBusy(true);
    try {
      const now = new Date().toISOString();
      // Only deduct reagents the FIRST time this result is completed (avoid double-deduct on edits).
      const alreadyCompleted = result.status === "completed";
      const cleanUsed = used.filter(u => u.reagentId && u.qty > 0);
      await db.labResults.update(result.id!, { values, notes, freeResult, reagentsUsed: cleanUsed, status: "completed", resultBy: user?.name, resultAt: now, updatedAt: now });
      await logAudit("lab_result", user?.name || "—", { resource: "lab", resourceId: result.id, message: `${result.examName} · ${pName(result.patientId)}` });
      if (!alreadyCompleted) {
        for (const u of cleanUsed) {
          const rg = reagents.find(r => r.id === u.reagentId);
          if (!rg) continue;
          const newStock = Math.max(0, (rg.stock || 0) - u.qty);
          await db.labReagents.update(u.reagentId, { stock: newStock, updatedAt: now });
          await db.labReagentMovements.add({ reagentId: u.reagentId, reagentName: rg.name, type: "out", quantity: u.qty, reason: `Analyse: ${result.examName} · ${pName(result.patientId)}`, performedBy: user?.name, clinicId: cid(), createdAt: now } as any);
          await logAudit("reagent_out", user?.name || "—", { resource: "reagent", resourceId: u.reagentId, message: `${rg.name} -${u.qty} (${result.examName})` });
        }
      }
      toast.success(L.saved);
      setResult(null); setUsed([]); setFreeResult(""); await load();
    } finally { setBusy(false); }
  };
  const remove = async (r: LabResult) => { await db.labResults.update(r.id!, { deleted: true, updatedAt: new Date().toISOString() }); await logAudit("lab_delete", user?.name || "—", { resource: "lab", resourceId: r.id, message: `${r.examName} · ${pName(r.patientId)}` }); await load(); };

  const statusBadge = (s: string) => s === "completed"
    ? <Badge className="bg-green-100 text-green-700 border-green-300">{L.doneBadge}</Badge>
    : <Badge className="bg-yellow-100 text-yellow-700 border-yellow-300">{L.pendingBadge}</Badge>;

  const resultExam = result ? examById(result.examId) : null;
  const abnormal = (f: any, v: string) => {
    if (f.isSelect || f.isText || !v || (f.min === 0 && f.max === 0)) return false;
    const n = parseFloat(v); return !isNaN(n) && (n < f.min || n > f.max);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <h1 className="text-xl font-bold flex items-center gap-2"><FlaskConical className="w-5 h-5" /> {L.title}</h1>
        {view === "results" && <Button size="sm" onClick={() => setOrderOpen(true)} className="gap-1"><Plus className="w-4 h-4" /> {L.newOrder}</Button>}
      </div>

      <div className="flex gap-2">
        <Button size="sm" variant={view === "results" ? "default" : "outline"} className="gap-1" onClick={() => setView("results")}><FlaskConical className="w-4 h-4" /> {L.analyses}</Button>
        <Button size="sm" variant={view === "reagents" ? "default" : "outline"} className="gap-1" onClick={() => setView("reagents")}><FlaskRound className="w-4 h-4" /> {L.reagents}</Button>
      </div>

      {view === "reagents" && <LabReagents />}

      {view === "results" && (<>
      <div className="grid grid-cols-2 gap-3">
        <Card><CardContent className="p-3"><p className="text-xs text-muted-foreground">{L.pending}</p><p className="text-2xl font-bold text-yellow-600">{orderedCount}</p></CardContent></Card>
        <Card><CardContent className="p-3"><p className="text-xs text-muted-foreground">{L.done}</p><p className="text-2xl font-bold text-green-600">{doneCount}</p></CardContent></Card>
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="grid grid-cols-3 w-full">
          <TabsTrigger value="ordered">{L.pending}</TabsTrigger>
          <TabsTrigger value="completed">{L.done}</TabsTrigger>
          <TabsTrigger value="all">{L.all}</TabsTrigger>
        </TabsList>
      </Tabs>

      <div className="relative">
        <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
        <Input className="pl-9" placeholder={L.searchPh} value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      <div className="space-y-2">
        {filtered.length === 0 && <p className="text-sm text-muted-foreground">{L.none}</p>}
        {filtered.map(r => (
          <Card key={r.id}><CardContent className="p-3 flex items-center gap-3">
            <FlaskConical className="w-4 h-4 text-primary flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="font-medium truncate">{r.examName}</p>
              <p className="text-xs text-muted-foreground">{pName(r.patientId)} · {new Date(r.orderedAt).toLocaleDateString(lang === "en" ? "en-GB" : "fr-FR")}</p>
            </div>
            {statusBadge(r.status)}
            {r.status === "ordered"
              ? <Button size="sm" className="h-8 gap-1 text-xs" onClick={() => openResult(r)}><FileText className="w-3.5 h-3.5" /> {L.enter}</Button>
              : <Button size="sm" variant="outline" className="h-8 gap-1 text-xs" onClick={() => openResult(r)}>{L.view}</Button>}
            <Button size="icon" variant="ghost" className="h-8 w-8 text-destructive" onClick={() => remove(r)}><Trash2 className="w-3.5 h-3.5" /></Button>
          </CardContent></Card>
        ))}
      </div>
      </>)}

      {/* New order */}
      <Dialog open={orderOpen} onOpenChange={setOrderOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>{L.newOrderTitle}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><label className="text-sm">{L.patient}</label>
              <Select value={orderPatient} onValueChange={setOrderPatient}>
                <SelectTrigger><SelectValue placeholder={L.choose} /></SelectTrigger>
                <SelectContent>{patients.map(p => <SelectItem key={p.id} value={String(p.id)}>{p.firstName} {p.lastName}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><label className="text-sm">{L.exam}</label>
              <Select value={orderExam} onValueChange={setOrderExam}>
                <SelectTrigger><SelectValue placeholder={L.chooseExam} /></SelectTrigger>
                <SelectContent className="max-h-72">
                  {LAB_CATALOGUE.map((c: any) => (
                    <div key={c.category}>
                      <p className="px-2 py-1 text-[10px] font-bold uppercase text-muted-foreground">{c.category}</p>
                      {c.exams.map((e: any) => <SelectItem key={e.id} value={e.id}>{e.name}</SelectItem>)}
                    </div>
                  ))}
                  <SelectItem value="__custom__">{L.customExam}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {orderExam === "__custom__" && (
              <div><label className="text-sm">{L.customName}</label><Input value={customName} onChange={e => setCustomName(e.target.value)} placeholder={L.customName} autoFocus /></div>
            )}
          </div>
          <DialogFooter><Button variant="outline" onClick={() => setOrderOpen(false)}>{L.cancel}</Button><Button onClick={createOrder}>{L.create}</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Enter / view result */}
      <Dialog open={!!result} onOpenChange={v => { if (!v) setResult(null); }}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{result?.examName}</DialogTitle></DialogHeader>
          {result && (
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">{pName(result.patientId)}</p>
              {resultExam ? resultExam.fields.map((f: any) => {
                const v = values[f.key] || "";
                const bad = abnormal(f, v);
                return (
                  <div key={f.key} className="flex items-center gap-2">
                    <label className="text-sm flex-1">{f.label}{f.unit ? ` (${f.unit})` : ""}{!f.isSelect && !f.isText && (f.min || f.max) ? <span className="text-[10px] text-muted-foreground ml-1">[{f.min}–{f.max}]</span> : null}</label>
                    {f.isSelect ? (
                      <Select value={v} onValueChange={val => setValues(s => ({ ...s, [f.key]: val }))}>
                        <SelectTrigger className="w-44"><SelectValue placeholder="—" /></SelectTrigger>
                        <SelectContent>{f.options.map((o: string) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
                      </Select>
                    ) : (
                      <Input className={`w-44 ${bad ? "border-red-500 text-red-600 font-semibold" : ""}`} value={v} onChange={e => setValues(s => ({ ...s, [f.key]: e.target.value }))} />
                    )}
                  </div>
                );
              }) : (
                <Textarea rows={4} placeholder={L.freeResultPh} value={freeResult} onChange={e => setFreeResult(e.target.value)} />
              )}
              <Textarea placeholder={L.notes} value={notes} onChange={e => setNotes(e.target.value)} />

              {/* Reagents used — deducted from stock on save */}
              <div className="border-t pt-2 mt-1">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium">{L.reagentsUsed}</label>
                  <Button size="sm" variant="outline" className="h-7 text-xs" disabled={reagents.length === 0 || result.status === "completed"} onClick={() => setUsed(u => [...u, { reagentId: 0, name: "", qty: 1 }])}>+ {L.addReagent}</Button>
                </div>
                {reagents.length === 0 && <p className="text-xs text-muted-foreground mt-1">{L.noReagents}</p>}
                {used.map((u, i) => (
                  <div key={i} className="flex items-center gap-2 mt-1.5">
                    <Select value={u.reagentId ? String(u.reagentId) : ""} onValueChange={v => { const rg = reagents.find(r => r.id === Number(v)); setUsed(arr => arr.map((x, idx) => idx === i ? { reagentId: Number(v), name: rg?.name || "", qty: x.qty } : x)); }}>
                      <SelectTrigger className="flex-1 h-8"><SelectValue placeholder={L.pickReagent} /></SelectTrigger>
                      <SelectContent>{reagents.map(r => <SelectItem key={r.id} value={String(r.id)}>{r.name} ({r.stock} {r.unit})</SelectItem>)}</SelectContent>
                    </Select>
                    <Input type="number" min={1} className="w-16 h-8" value={u.qty} onChange={e => setUsed(arr => arr.map((x, idx) => idx === i ? { ...x, qty: parseInt(e.target.value) || 1 } : x))} title={L.qty} />
                    <Button size="icon" variant="ghost" className="h-8 w-8 text-destructive" onClick={() => setUsed(arr => arr.filter((_, idx) => idx !== i))}><Trash2 className="w-3.5 h-3.5" /></Button>
                  </div>
                ))}
                {result.status === "completed" && used.length > 0 && <p className="text-[10px] text-muted-foreground mt-1">Déjà déduit du stock.</p>}
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setResult(null)}>{L.close}</Button>
            <Button onClick={saveResult} disabled={busy}>{result?.status === "completed" ? L.update : L.save}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
