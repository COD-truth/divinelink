import { getClinicSettings } from "@/lib/clinicSettings";

export interface ReceiptLineItem {
  description: string;
  tooth?: string;
  lot?: string;
  quantity: number;
  unitPrice: number;
}

export interface ReceiptData {
  receiptNumber: string;
  date: string;
  patientName: string;
  patientDob?: string;
  patientId?: string;
  items: ReceiptLineItem[];
  discount?: number;
  discountType?: "amount" | "percent";
  paymentMethod: string;
  status: "paid" | "partial" | "unpaid";
  amountPaid?: number;
  amountDue?: number;
  notes?: string;
  isProforma?: boolean;
  cashier?: string;
}

const METHOD_LABELS: Record<string, string> = {
  cash: "Especes / Cash",
  mtn_momo: "MTN Mobile Money",
  orange_money: "Orange Money",
  insurance: "Assurance / Insurance",
  other: "Autre / Other",
};

export function generateReceipt(data: ReceiptData) {
  import("jspdf").then(({ jsPDF }) => {
    const clinic = getClinicSettings();
    const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a5" });
    const W = 148;
    const mg = 12;
    let y = 14;
    const TEAL: [number,number,number] = [13,148,136];
    const DARK: [number,number,number] = [15,23,42];
    const GREY: [number,number,number] = [100,116,139];
    const RED: [number,number,number] = [220,38,38];
    const GREEN: [number,number,number] = [22,163,74];

    // ── HEADER ──────────────────────────────────────────────
    doc.setFillColor(...TEAL);
    doc.rect(0, 0, W, 28, "F");
    doc.setTextColor(255,255,255);
    doc.setFontSize(13);
    doc.setFont("helvetica","bold");
    doc.text(clinic?.name || "Cabinet Medical", W/2, 9, {align:"center"});
    doc.setFontSize(7.5);
    doc.setFont("helvetica","normal");
    if (clinic?.address) doc.text(clinic.address + (clinic.city ? ", " + clinic.city : ""), W/2, 14, {align:"center"});
    if (clinic?.phone) doc.text("Tel: " + clinic.phone, W/2, 18, {align:"center"});
    if (clinic?.licenseNumber) doc.text("N° Agrément: " + clinic.licenseNumber, W/2, 22, {align:"center"});
    y = 32;

    // ── DOCUMENT TITLE ───────────────────────────────────────
    const title = data.isProforma ? "FACTURE PROFORMA" : data.status === "paid" ? "RECU DE PAIEMENT" : "FACTURE";
    doc.setFillColor(240,253,250);
    doc.rect(mg, y, W-mg*2, 10, "F");
    doc.setDrawColor(...TEAL);
    doc.rect(mg, y, W-mg*2, 10, "S");
    doc.setTextColor(...TEAL);
    doc.setFontSize(12);
    doc.setFont("helvetica","bold");
    doc.text(title, W/2, y+7, {align:"center"});
    y += 14;

    // ── RECEIPT INFO ─────────────────────────────────────────
    doc.setFontSize(8);
    doc.setTextColor(...DARK);
    doc.setFont("helvetica","normal");
    
    // Two-column info block
    const col1x = mg;
    const col2x = W/2 + 2;
    
    doc.setFont("helvetica","bold");
    doc.text("N° Document:", col1x, y);
    doc.setFont("helvetica","normal");
    doc.text(data.receiptNumber, col1x + 28, y);
    
    doc.setFont("helvetica","bold");
    doc.text("Date:", col2x, y);
    doc.setFont("helvetica","normal");
    doc.text(data.date, col2x + 12, y);
    y += 5;

    doc.setFont("helvetica","bold");
    doc.text("Patient:", col1x, y);
    doc.setFont("helvetica","normal");
    doc.text(data.patientName, col1x + 28, y);

    if (data.patientDob) {
      doc.setFont("helvetica","bold");
      doc.text("DDN:", col2x, y);
      doc.setFont("helvetica","normal");
      doc.text(data.patientDob, col2x + 12, y);
    }
    y += 5;

    if (data.patientId) {
      doc.setFont("helvetica","bold");
      doc.text("ID Patient:", col1x, y);
      doc.setFont("helvetica","normal");
      doc.text(data.patientId, col1x + 28, y);
      y += 5;
    }

    doc.setFont("helvetica","bold");
    doc.text("Mode paiement:", col1x, y);
    doc.setFont("helvetica","normal");
    doc.text(METHOD_LABELS[data.paymentMethod] || data.paymentMethod, col1x + 35, y);
    y += 8;

    // ── DIVIDER ──────────────────────────────────────────────
    doc.setDrawColor(...TEAL);
    doc.setLineWidth(0.5);
    doc.line(mg, y, W-mg, y);
    y += 4;

    // ── LINE ITEMS TABLE ─────────────────────────────────────
    // Header
    doc.setFillColor(...TEAL);
    doc.rect(mg, y, W-mg*2, 7, "F");
    doc.setTextColor(255,255,255);
    doc.setFontSize(7.5);
    doc.setFont("helvetica","bold");
    doc.text("Designation", mg+2, y+5);
    doc.text("Dent", mg+62, y+5, {align:"center"});
    doc.text("Qte", mg+78, y+5, {align:"center"});
    doc.text("P.U (FCFA)", mg+95, y+5, {align:"center"});
    doc.text("Total (FCFA)", W-mg-2, y+5, {align:"right"});
    y += 7;

    // Rows
    let subtotal = 0;
    data.items.forEach((item, i) => {
      const total = item.quantity * item.unitPrice;
      subtotal += total;
      const rowH = item.lot ? 11 : 7;
      if (i % 2 === 0) {
        doc.setFillColor(248,250,252);
        doc.rect(mg, y, W-mg*2, rowH, "F");
      }
      doc.setTextColor(...DARK);
      doc.setFont("helvetica","normal");
      doc.setFontSize(7.5);

      // Truncate long descriptions
      const desc = item.description.length > 30 ? item.description.substring(0,28)+"..." : item.description;
      doc.text(desc, mg+2, y+5);
      doc.text(item.tooth || "-", mg+62, y+5, {align:"center"});
      doc.text(String(item.quantity), mg+78, y+5, {align:"center"});
      doc.text(item.unitPrice.toLocaleString(), mg+95, y+5, {align:"center"});
      doc.setFont("helvetica","bold");
      doc.text(total.toLocaleString(), W-mg-2, y+5, {align:"right"});
      // LOT number line under the designation (matches local clinic receipts)
      if (item.lot) {
        doc.setFont("helvetica","normal");
        doc.setFontSize(6.5);
        doc.setTextColor(...GREY);
        doc.text("N: " + item.lot, mg+4, y+9);
        doc.setTextColor(...DARK);
        doc.setFontSize(7.5);
      }
      y += rowH;
    });
    y += 2;

    // ── TOTALS ───────────────────────────────────────────────
    doc.setDrawColor(...GREY);
    doc.setLineWidth(0.3);
    doc.line(mg, y, W-mg, y);
    y += 4;

    const totalsX = W - mg - 50;
    const valX = W - mg - 2;

    // Subtotal
    doc.setFontSize(8);
    doc.setFont("helvetica","normal");
    doc.setTextColor(...DARK);
    doc.text("Sous-total:", totalsX, y);
    doc.setFont("helvetica","bold");
    doc.text(subtotal.toLocaleString() + " FCFA", valX, y, {align:"right"});
    y += 5;

    // Discount
    let discountAmount = 0;
    if (data.discount && data.discount > 0) {
      discountAmount = data.discountType === "percent" ? Math.round(subtotal * data.discount / 100) : data.discount;
      doc.setFont("helvetica","normal");
      doc.setTextColor(...DARK);
      doc.text("Remise" + (data.discountType === "percent" ? " (" + data.discount + "%)" : "") + ":", totalsX, y);
      doc.setFont("helvetica","bold");
      doc.setTextColor(...RED);
      doc.text("-" + discountAmount.toLocaleString() + " FCFA", valX, y, {align:"right"});
      y += 5;
    }

    // Total
    const totalDue = subtotal - discountAmount;
    doc.setFillColor(...TEAL);
    doc.rect(totalsX-4, y-3, W-mg-(totalsX-4), 9, "F");
    doc.setTextColor(255,255,255);
    doc.setFont("helvetica","bold");
    doc.setFontSize(9);
    doc.text("TOTAL DU:", totalsX, y+4);
    doc.text(totalDue.toLocaleString() + " FCFA", valX, y+4, {align:"right"});
    y += 12;

    // Amount paid / balance
    if (data.amountPaid !== undefined && data.amountPaid !== null) {
      doc.setFontSize(8);
      doc.setFont("helvetica","normal");
      doc.setTextColor(...DARK);
      doc.text("Montant regle:", totalsX, y);
      doc.setFont("helvetica","bold");
      doc.setTextColor(...GREEN);
      doc.text(data.amountPaid.toLocaleString() + " FCFA", valX, y, {align:"right"});
      y += 5;

      const balance = totalDue - data.amountPaid;
      if (balance > 0) {
        doc.setFont("helvetica","normal");
        doc.setTextColor(...DARK);
        doc.text("Reste a payer:", totalsX, y);
        doc.setFont("helvetica","bold");
        doc.setTextColor(...RED);
        doc.text(balance.toLocaleString() + " FCFA", valX, y, {align:"right"});
        y += 5;
      }
    }
    y += 3;

    // ── STATUS BADGE ─────────────────────────────────────────
    const statusColors: Record<string,[number,number,number]> = {
      paid: GREEN, partial: [234,179,8], unpaid: RED
    };
    const statusLabels: Record<string,string> = {
      paid: "PAYE / PAID", partial: "PAIEMENT PARTIEL", unpaid: "IMPAYE / UNPAID"
    };
    const sc = statusColors[data.status] || GREY;
    doc.setFillColor(...sc);
    doc.roundedRect(mg, y, 40, 8, 2, 2, "F");
    doc.setTextColor(255,255,255);
    doc.setFontSize(7);
    doc.setFont("helvetica","bold");
    doc.text(statusLabels[data.status] || data.status.toUpperCase(), mg+20, y+5.5, {align:"center"});
    y += 12;

    // ── NOTES ────────────────────────────────────────────────
    if (data.notes) {
      doc.setFontSize(7.5);
      doc.setFont("helvetica","normal");
      doc.setTextColor(...GREY);
      doc.text("Note: " + data.notes, mg, y);
      y += 6;
    }

    // ── SIGNATURES ───────────────────────────────────────────
    y = Math.max(y, 175);
    doc.setDrawColor(...GREY);
    doc.setLineWidth(0.3);
    doc.line(mg, y, mg+45, y);
    doc.line(W-mg-45, y, W-mg, y);
    doc.setTextColor(...GREY);
    doc.setFontSize(7);
    doc.text("Signature du Responsable", mg+22, y+4, {align:"center"});
    doc.text("Signature du Patient", W-mg-22, y+4, {align:"center"});
    y += 10;

    // ── FOOTER ───────────────────────────────────────────────
    doc.setFillColor(...TEAL);
    doc.rect(0, 205, W, 8, "F");
    doc.setTextColor(255,255,255);
    doc.setFontSize(6.5);
    doc.text("Genere par DivineLink  |  " + (clinic?.name || "Cabinet Medical") + "  |  " + data.date, W/2, 210, {align:"center"});

    const filename = (data.isProforma ? "proforma" : "recu") + "_" + data.receiptNumber + ".pdf";
    doc.save(filename);
  });
}
// ─────────────────────────────────────────────────────────────────────────────
// THERMAL 80mm RECEIPT — faithful to local clinic receipts (CENTRE MÉDICAL…)
// Black & white, narrow roll, QTÉ / NOM / PT.TTC, LOT lines, Net à Payer /
// Acompte / Reste, status box, and a scannable Code 39 barcode of the invoice №.
// ─────────────────────────────────────────────────────────────────────────────
const CODE39: Record<string, string> = {
  "0":"000110100","1":"100100001","2":"001100001","3":"101100000","4":"000110001",
  "5":"100110000","6":"001110000","7":"000100101","8":"100100100","9":"001100100",
  "*":"010010100",
};

export function generateThermalReceipt(data: ReceiptData) {
  import("jspdf").then(({ jsPDF }) => {
    const clinic = getClinicSettings();
    const W = 80;                 // 80mm thermal roll
    const mg = 4;
    const CW = W - mg * 2;        // content width
    const cur = clinic?.currency || "FCFA";

    // Pre-compute height from the number of items so the roll is the right length.
    let bodyH = 0;
    data.items.forEach(it => { bodyH += it.lot ? 8 : 5; });
    const H = 86 + bodyH + 34;    // header + items + totals/barcode/footer

    const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: [W, H] });
    const line = (y: number) => { doc.setLineDashPattern([0.6, 0.6], 0); doc.setDrawColor(0); doc.setLineWidth(0.2); doc.line(mg, y, W - mg, y); doc.setLineDashPattern([], 0); };
    // Plain thousands separator (a regular space) — the fr-FR locale uses a
    // narrow no-break space that renders as "/" in the jsPDF core font.
    const fmt = (n: number) => Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
    const money = (n: number) => fmt(n) + " " + cur;
    let y = 7;

    // ── Header ──
    doc.setTextColor(0);
    doc.setFont("helvetica", "bold"); doc.setFontSize(11);
    doc.text((clinic?.name || "CENTRE MÉDICAL").toUpperCase(), W / 2, y, { align: "center" }); y += 5;
    doc.setFont("helvetica", "normal"); doc.setFontSize(7);
    if (clinic?.phone) { doc.text("Contacts: " + clinic.phone, W / 2, y, { align: "center" }); y += 3.5; }
    if (clinic?.address) { doc.text("Adresse: " + clinic.address + (clinic.city ? ", " + clinic.city : ""), W / 2, y, { align: "center" }); y += 3.5; }
    y += 1; line(y); y += 5;

    // ── Title + meta ──
    doc.setFont("helvetica", "bold"); doc.setFontSize(10);
    doc.text(data.isProforma ? "FACTURE PROFORMA" : "FACTURE", W / 2, y, { align: "center" }); y += 5;
    doc.setFontSize(8);
    doc.text("Facture N° : " + data.receiptNumber, W / 2, y, { align: "center" }); y += 5;
    doc.setFont("helvetica", "normal"); doc.setFontSize(7.5);
    doc.text("Client : " + data.patientName, mg, y); y += 3.6;
    if (data.cashier) { doc.text("Caissier : " + data.cashier, mg, y); y += 3.6; }
    doc.text("FACTURE DU : " + data.date, mg, y); y += 3;
    line(y); y += 4;

    // ── Column header ──
    doc.setFont("helvetica", "bold"); doc.setFontSize(7.5);
    doc.text("QTÉ", mg, y);
    doc.text("NOM", mg + 10, y);
    doc.text("PT.TTC", W - mg, y, { align: "right" });
    y += 1.5; line(y); y += 4;

    // ── Items ──
    let subtotal = 0;
    doc.setFont("helvetica", "normal"); doc.setFontSize(7.5);
    data.items.forEach(it => {
      const total = it.quantity * it.unitPrice;
      subtotal += total;
      doc.text(String(it.quantity), mg + 1, y, { align: "center" });
      const name = it.description.length > 26 ? it.description.slice(0, 25) + "…" : it.description;
      doc.text(name.toUpperCase(), mg + 10, y);
      doc.text(fmt(total), W - mg, y, { align: "right" });
      y += 4;
      if (it.lot) { doc.setFontSize(6.3); doc.setTextColor(90); doc.text("N:" + it.lot, mg + 10, y); doc.setTextColor(0); doc.setFontSize(7.5); y += 4; }
    });
    y += 1; line(y); y += 5;

    // ── Totals ──
    const paid = data.amountPaid ?? 0;
    const due = data.amountDue ?? subtotal;
    const reste = Math.max(0, due - paid);
    const rowR = (label: string, val: string, bold = false, size = 8) => {
      doc.setFont("helvetica", bold ? "bold" : "normal"); doc.setFontSize(size);
      doc.text(label, mg, y); doc.text(val, W - mg, y, { align: "right" }); y += bold ? 5.5 : 4.2;
    };
    rowR("Sous-total HT:", money(subtotal));
    rowR("TVA 0%:", money(0));
    line(y); y += 4;
    rowR("Net À Payer:", money(due), true, 10);
    rowR("Acompte:", money(paid));
    rowR("Reste:", money(reste), true, 9);
    y += 2;

    // ── Status box ──
    const label = data.status === "paid" ? "Payée" : data.status === "partial" ? "Acompte" : "Non payée";
    doc.setDrawColor(0); doc.setLineWidth(0.3);
    const bw = 34, bx = (W - bw) / 2;
    doc.roundedRect(bx, y, bw, 7, 1, 1, "S");
    doc.setFont("helvetica", "bold"); doc.setFontSize(9);
    doc.text(label, W / 2, y + 4.8, { align: "center" });
    y += 12;

    // ── Code 39 barcode of the invoice number ──
    const code = "*" + data.receiptNumber.replace(/[^0-9]/g, "") + "*";
    const narrow = 0.33, wide = narrow * 2.3, barH = 11;
    let totalW = 0;
    for (const ch of code) { const p = CODE39[ch] || CODE39["0"]; for (let i = 0; i < 9; i++) totalW += (p[i] === "1" ? wide : narrow); totalW += narrow; }
    let cx = (W - totalW) / 2;
    doc.setFillColor(0);
    for (const ch of code) {
      const p = CODE39[ch] || CODE39["0"];
      for (let i = 0; i < 9; i++) { const w = p[i] === "1" ? wide : narrow; if (i % 2 === 0) doc.rect(cx, y, w, barH, "F"); cx += w; }
      cx += narrow;
    }
    y += barH + 3;
    doc.setFont("helvetica", "normal"); doc.setFontSize(6.5); doc.setTextColor(90);
    doc.text("Généré par DivineLink", W / 2, y, { align: "center" });

    doc.save("facture_" + data.receiptNumber + ".pdf");
  });
}
