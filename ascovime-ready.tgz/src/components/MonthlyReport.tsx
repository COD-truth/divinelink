import { useEffect, useMemo, useState } from "react";
import { db, type Patient, type Consultation, type Payment, type LabResult } from "@/lib/db";
import { decryptPatients } from "@/lib/patientCrypto";
import { useLang } from "@/contexts/LangContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RTooltip, ResponsiveContainer } from "recharts";
import { Download, Printer, CalendarRange } from "lucide-react";
import { saveFile, toCsv } from "@/lib/download";
import { toast } from "sonner";

const DICT = {
  fr: {
    title: "Rapport mensuel", month: "Mois", export: "Exporter CSV", print: "Imprimer",
    consults: "Consultations", newPatients: "Nouveaux patients", seen: "Patients vus",
    appointments: "Rendez-vous", labTests: "Analyses labo", revenue: "Recette encaissée",
    revByMethod: "Recette par mode de paiement", billed: "Total facturé", unpaid: "Impayés",
    cash: "Espèces", orange_money: "Orange Money", mtn_momo: "MTN MoMo", other: "Autre",
    topDx: "Top 10 diagnostics", diagnosis: "Diagnostic", count: "Nombre",
    ageDist: "Répartition par âge", ageGroup: "Tranche d'âge",
    lab: "Laboratoire", labOrdered: "Demandées", labDone: "Terminées", topExams: "Examens les plus demandés",
    pharmacy: "Pharmacie", unitsSold: "Unités vendues", pharmRevenue: "CA pharmacie",
    byDay: "Consultations par jour", noData: "Aucune donnée pour ce mois.",
    summaryFor: "Résumé pour", generatedOn: "Généré le",
  },
  en: {
    title: "Monthly Report", month: "Month", export: "Export CSV", print: "Print",
    consults: "Consultations", newPatients: "New patients", seen: "Patients seen",
    appointments: "Appointments", labTests: "Lab tests", revenue: "Revenue collected",
    revByMethod: "Revenue by payment method", billed: "Total billed", unpaid: "Unpaid",
    cash: "Cash", orange_money: "Orange Money", mtn_momo: "MTN MoMo", other: "Other",
    topDx: "Top 10 diagnoses", diagnosis: "Diagnosis", count: "Count",
    ageDist: "Age distribution", ageGroup: "Age group",
    lab: "Laboratory", labOrdered: "Ordered", labDone: "Completed", topExams: "Most requested exams",
    pharmacy: "Pharmacy", unitsSold: "Units sold", pharmRevenue: "Pharmacy revenue",
    byDay: "Consultations per day", noData: "No data for this month.",
    summaryFor: "Summary for", generatedOn: "Generated on",
  },
};

function ageFromDob(dob: string, ageYears?: number): number | null {
  if (typeof ageYears === "number" && ageYears > 0) return ageYears;
  if (!dob) return null;
  const d = new Date(dob);
  if (isNaN(d.getTime())) return null;
  return Math.floor((Date.now() - d.getTime()) / (365.25 * 24 * 3600 * 1000));
}
function ageBucket(a: number | null): string {
  if (a === null) return "?";
  if (a <= 12) return "0-12";
  if (a <= 17) return "13-17";
  if (a <= 35) return "18-35";
  if (a <= 60) return "36-60";
  return "60+";
}

export function MonthlyReport() {
  const { lang } = useLang();
  const L = DICT[lang] || DICT.fr;
  const cid = () => localStorage.getItem("divinelink.clinicId") || undefined;
  const inClinic = (c?: string) => { const a = cid(); return !a || !c || String(c) === String(a); };

  const [month, setMonth] = useState(() => new Date().toISOString().slice(0, 7));
  const [patients, setPatients] = useState<Patient[]>([]);
  const [consultations, setConsultations] = useState<Consultation[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [labs, setLabs] = useState<LabResult[]>([]);
  const [appointments, setAppointments] = useState<any[]>([]);

  useEffect(() => {
    (async () => {
      const [p, c, pay, lab, apt] = await Promise.all([
        db.patients.toArray().then(decryptPatients),
        db.consultations.toArray(),
        db.payments.toArray(),
        db.labResults.toArray(),
        db.appointments.toArray(),
      ]);
      setPatients(p.filter(x => !x.deleted && inClinic(x.clinicId)));
      setConsultations(c.filter(x => inClinic((x as any).clinicId)));
      setPayments(pay.filter(x => !(x as any).deleted && inClinic(x.clinicId)));
      setLabs(lab.filter(x => !x.deleted && inClinic(x.clinicId)));
      setAppointments(apt.filter(x => inClinic((x as any).clinicId)));
    })();
  }, []);

  const inMonth = (ts?: string) => !!ts && ts.slice(0, 7) === month;

  const stats = useMemo(() => {
    const monthConsults = consultations.filter(c => c.isLatest !== false && inMonth(c.createdAt || c.date));
    const newPatients = patients.filter(p => inMonth(p.createdAt)).length;
    const seenIds = new Set(monthConsults.map(c => c.patientId));
    const monthApts = appointments.filter(a => inMonth(a.date || a.createdAt)).length;

    // Lab
    const monthLabs = labs.filter(l => inMonth(l.orderedAt || l.createdAt));
    const labDone = monthLabs.filter(l => l.status === "completed").length;
    const examCounts = new Map<string, number>();
    monthLabs.forEach(l => examCounts.set(l.examName, (examCounts.get(l.examName) || 0) + 1));
    const topExams = Array.from(examCounts.entries()).sort((a, b) => b[1] - a[1]).slice(0, 6);

    // Revenue (same model as caisse closing: installments or synthesized)
    const byMethod: Record<string, number> = { cash: 0, orange_money: 0, mtn_momo: 0, other: 0 };
    let revenue = 0;
    payments.forEach(p => {
      const insts = (p.installments && p.installments.length)
        ? p.installments
        : (p.amountPaid > 0 ? [{ amount: p.amountPaid, method: p.method, paidAt: p.paidAt || p.createdAt }] : []);
      insts.forEach(it => {
        if (inMonth(it.paidAt as string)) { byMethod[it.method] = (byMethod[it.method] || 0) + it.amount; revenue += it.amount; }
      });
    });
    const monthInvoices = payments.filter(p => inMonth(p.createdAt));
    const billed = monthInvoices.reduce((s, p) => s + (p.amountDue || 0), 0);
    const unpaid = monthInvoices.reduce((s, p) => s + Math.max(0, (p.amountDue || 0) - (p.amountPaid || 0)), 0);

    // Pharmacy units + revenue from invoice line items
    let pharmUnits = 0, pharmRevenue = 0;
    monthInvoices.forEach(p => (p.items || []).forEach(it => {
      if (it.drugId || (it.category || "").toLowerCase().includes("pharm")) {
        pharmUnits += it.quantity || 0;
        pharmRevenue += (it.quantity || 0) * (it.unitPrice || 0);
      }
    }));

    // Top diagnoses
    const dxCounts = new Map<string, number>();
    monthConsults.forEach(c => { const k = (c.diagnosis || "").trim(); if (k) dxCounts.set(k, (dxCounts.get(k) || 0) + 1); });
    const topDx = Array.from(dxCounts.entries()).sort((a, b) => b[1] - a[1]).slice(0, 10);

    // Age distribution of patients seen
    const ageBuckets: Record<string, number> = { "0-12": 0, "13-17": 0, "18-35": 0, "36-60": 0, "60+": 0, "?": 0 };
    patients.filter(p => seenIds.has(p.id!)).forEach(p => { ageBuckets[ageBucket(ageFromDob(p.dob, p.ageYears))]++; });

    // Per-day
    const daysInMonth = new Date(Number(month.slice(0, 4)), Number(month.slice(5, 7)), 0).getDate();
    const perDay = Array.from({ length: daysInMonth }, (_, i) => ({ day: String(i + 1), value: 0 }));
    monthConsults.forEach(c => {
      const d = (c.createdAt || c.date).slice(8, 10);
      const idx = Number(d) - 1;
      if (idx >= 0 && idx < perDay.length) perDay[idx].value++;
    });

    return {
      consults: monthConsults.length, newPatients, seen: seenIds.size, apts: monthApts,
      labOrdered: monthLabs.length, labDone, topExams,
      byMethod, revenue, billed, unpaid, pharmUnits, pharmRevenue,
      topDx, ageBuckets, perDay,
    };
  }, [consultations, patients, payments, labs, appointments, month]);

  const f = (n: number) => Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
  const monthLabel = new Date(month + "-01").toLocaleDateString(lang === "en" ? "en-GB" : "fr-FR", { month: "long", year: "numeric" });

  const exportCsv = async () => {
    const rows: Record<string, unknown>[] = [
      { indicateur: L.consults, valeur: stats.consults },
      { indicateur: L.newPatients, valeur: stats.newPatients },
      { indicateur: L.seen, valeur: stats.seen },
      { indicateur: L.appointments, valeur: stats.apts },
      { indicateur: L.labTests + " (" + L.labOrdered + ")", valeur: stats.labOrdered },
      { indicateur: L.labTests + " (" + L.labDone + ")", valeur: stats.labDone },
      { indicateur: L.revenue + " (FCFA)", valeur: Math.round(stats.revenue) },
      { indicateur: L.billed + " (FCFA)", valeur: Math.round(stats.billed) },
      { indicateur: L.unpaid + " (FCFA)", valeur: Math.round(stats.unpaid) },
      { indicateur: L.cash, valeur: Math.round(stats.byMethod.cash) },
      { indicateur: L.orange_money, valeur: Math.round(stats.byMethod.orange_money) },
      { indicateur: L.mtn_momo, valeur: Math.round(stats.byMethod.mtn_momo) },
      { indicateur: L.other, valeur: Math.round(stats.byMethod.other) },
      { indicateur: L.unitsSold, valeur: stats.pharmUnits },
      { indicateur: L.pharmRevenue + " (FCFA)", valeur: Math.round(stats.pharmRevenue) },
      {},
      { indicateur: "=== " + L.topDx + " ===", valeur: "" },
      ...stats.topDx.map(([name, c]) => ({ indicateur: name, valeur: c })),
      {},
      { indicateur: "=== " + L.ageDist + " ===", valeur: "" },
      ...Object.entries(stats.ageBuckets).map(([k, v]) => ({ indicateur: k, valeur: v })),
    ];
    const csv = toCsv(rows as any, ["indicateur", "valeur"]);
    const ok = await saveFile(`rapport-${month}.csv`, csv, "csv");
    if (ok) toast.success(L.export + " ✓");
  };

  const methodRows = [
    ["cash", stats.byMethod.cash], ["orange_money", stats.byMethod.orange_money],
    ["mtn_momo", stats.byMethod.mtn_momo], ["other", stats.byMethod.other],
  ] as [keyof typeof L, number][];

  return (
    <div className="space-y-4">
      <div className="flex items-end justify-between gap-2 flex-wrap print:hidden">
        <div>
          <label className="text-xs text-muted-foreground flex items-center gap-1"><CalendarRange className="w-3.5 h-3.5" /> {L.month}</label>
          <Input type="month" value={month} onChange={e => setMonth(e.target.value)} className="w-44" />
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={exportCsv} className="gap-1"><Download className="w-4 h-4" /> {L.export}</Button>
          <Button variant="outline" size="sm" onClick={() => window.print()} className="gap-1"><Printer className="w-4 h-4" /> {L.print}</Button>
        </div>
      </div>

      <div className="hidden print:block mb-2">
        <h2 className="text-lg font-bold">{L.summaryFor} {monthLabel}</h2>
        <p className="text-xs text-muted-foreground">{L.generatedOn} {new Date().toLocaleDateString(lang === "en" ? "en-GB" : "fr-FR")}</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <KPI label={L.consults} value={stats.consults} />
        <KPI label={L.newPatients} value={stats.newPatients} />
        <KPI label={L.seen} value={stats.seen} />
        <KPI label={L.appointments} value={stats.apts} />
        <KPI label={L.labTests} value={stats.labOrdered} />
        <KPI label={L.revenue} value={`${f(stats.revenue)}`} suffix="F" accent />
      </div>

      <div className="grid md:grid-cols-2 gap-3">
        {/* Revenue by method */}
        <Card>
          <CardHeader><CardTitle className="text-base">{L.revByMethod}</CardTitle></CardHeader>
          <CardContent className="space-y-1.5">
            {methodRows.filter(([, v]) => v > 0).length === 0 && <p className="text-sm text-muted-foreground">{L.noData}</p>}
            {methodRows.filter(([, v]) => v > 0).map(([m, v]) => (
              <div key={m} className="flex justify-between text-sm"><span>{L[m]}</span><b>{f(v)} F</b></div>
            ))}
            <div className="border-t pt-1.5 mt-1.5 flex justify-between text-sm font-bold"><span>{L.revenue}</span><span className="text-success">{f(stats.revenue)} F</span></div>
            <div className="flex justify-between text-sm text-muted-foreground"><span>{L.billed}</span><span>{f(stats.billed)} F</span></div>
            <div className="flex justify-between text-sm text-destructive"><span>{L.unpaid}</span><span>{f(stats.unpaid)} F</span></div>
          </CardContent>
        </Card>

        {/* Age distribution */}
        <Card>
          <CardHeader><CardTitle className="text-base">{L.ageDist}</CardTitle></CardHeader>
          <CardContent className="space-y-1.5">
            {Object.entries(stats.ageBuckets).map(([k, v]) => {
              const max = Math.max(1, ...Object.values(stats.ageBuckets));
              return (
                <div key={k} className="flex items-center gap-2 text-sm">
                  <span className="w-14 text-muted-foreground">{k}</span>
                  <div className="flex-1 h-3 bg-muted rounded"><div className="h-3 bg-primary rounded" style={{ width: `${(v / max) * 100}%` }} /></div>
                  <span className="w-8 text-right font-medium">{v}</span>
                </div>
              );
            })}
          </CardContent>
        </Card>
      </div>

      {/* Lab + Pharmacy */}
      <div className="grid md:grid-cols-2 gap-3">
        <Card>
          <CardHeader><CardTitle className="text-base">{L.lab}</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            <div className="flex gap-4">
              <div><p className="text-xs text-muted-foreground">{L.labOrdered}</p><p className="text-2xl font-bold">{stats.labOrdered}</p></div>
              <div><p className="text-xs text-muted-foreground">{L.labDone}</p><p className="text-2xl font-bold text-green-600">{stats.labDone}</p></div>
            </div>
            {stats.topExams.length > 0 && (
              <div className="pt-1">
                <p className="text-xs font-semibold text-muted-foreground mb-1">{L.topExams}</p>
                <ul className="space-y-0.5">{stats.topExams.map(([name, c]) => (
                  <li key={name} className="flex justify-between text-sm"><span className="truncate">{name}</span><Badge variant="secondary">{c}</Badge></li>
                ))}</ul>
              </div>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="text-base">{L.pharmacy}</CardTitle></CardHeader>
          <CardContent>
            <div className="flex gap-4">
              <div><p className="text-xs text-muted-foreground">{L.unitsSold}</p><p className="text-2xl font-bold">{stats.pharmUnits}</p></div>
              <div><p className="text-xs text-muted-foreground">{L.pharmRevenue}</p><p className="text-2xl font-bold text-success">{f(stats.pharmRevenue)} F</p></div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Top diagnoses */}
      <Card>
        <CardHeader><CardTitle className="text-base">{L.topDx}</CardTitle></CardHeader>
        <CardContent>
          {stats.topDx.length === 0 ? <p className="text-sm text-muted-foreground">{L.noData}</p> : (
            <Table>
              <TableHeader><TableRow><TableHead>{L.diagnosis}</TableHead><TableHead className="text-right">{L.count}</TableHead></TableRow></TableHeader>
              <TableBody>{stats.topDx.map(([name, c]) => (
                <TableRow key={name}><TableCell className="font-medium">{name}</TableCell><TableCell className="text-right">{c}</TableCell></TableRow>
              ))}</TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Per-day chart */}
      <Card className="print:break-inside-avoid">
        <CardHeader><CardTitle className="text-base">{L.byDay}</CardTitle></CardHeader>
        <CardContent className="h-56">
          <ResponsiveContainer>
            <BarChart data={stats.perDay}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="day" tick={{ fontSize: 10 }} interval={2} />
              <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
              <RTooltip />
              <Bar dataKey="value" fill="hsl(var(--primary))" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}

function KPI({ label, value, suffix, accent }: { label: string; value: React.ReactNode; suffix?: string; accent?: boolean }) {
  return (
    <Card><CardContent className="p-3">
      <p className="text-xs text-muted-foreground leading-tight">{label}</p>
      <p className={`text-2xl font-bold mt-0.5 ${accent ? "text-success" : ""}`}>{value}{suffix && <span className="text-sm font-normal ml-0.5">{suffix}</span>}</p>
    </CardContent></Card>
  );
}
