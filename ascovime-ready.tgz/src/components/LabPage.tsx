import { useEffect, useMemo, useState } from "react";
import { db, type Patient, type LabResult } from "@/lib/db";
import { decryptPatients } from "@/lib/patientCrypto";
import { useAuth } from "@/contexts/AuthContext";
import { useLang } from "@/contexts/LangContext";
import { LAB_CATALOGUE } from "./LabResultsPage";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FlaskConical, Search, Plus, Trash2, FileText, FlaskRound } from "lucide-react";
import { toast } from "sonner";
import { LabReagents } from "./LabReagents";

const DICT = {
  fr: {
    title: "Laboratoire", newOrder: "Nouvelle demande", analyses: "Analyses", reagents: "Réactifs",
    pending: "En attente", done: "Terminés", all: "Tous", searchPh: "Rechercher patient ou examen…",
    none: "Aucune analyse.", enter: "Saisir", view: "Voir", newOrderTitle: "Nouvelle demande d'analyse",
    patient: "Patient", choose: "Choisir…", exam: "Examen", chooseExam: "Choisir un examen…",
    cancel: "Annuler", create: "Créer la demande", notes: "Notes / interprétation…",
    close: "Fermer", update: "Mettre à jour", save: "Enregistrer le résultat",
    needBoth: "Patient et examen requis", created: "Demande créée", saved: "Résultat enregistré",
    doneBadge: "Terminé", pendingBadge: "En attente",
  },
  en: {
    title: "Laboratory", newOrder: "New request", analyses: "Analyses", reagents: "Reagents",
    pending: "Pending", done: "Completed", all: "All", searchPh: "Search patient or exam…",
    none: "No analyses.", enter: "Enter", view: "View", newOrderTitle: "New analysis request",
    patient: "Patient", choose: "Select…", exam: "Exam", chooseExam: "Select an exam…",
    cancel: "Cancel", create: "Create request", notes: "Notes / interpretation…",
    close: "Close", update: "Update", save: "Save result",
    needBoth: "Patient and exam required", created: "Request created", saved: "Result saved",
    doneBadge: "Completed", pendingBadge: "Pending",
  },
};

const ALL_EXAMS = LAB_CATALOGUE.flatMap((c: any) => c.exams.map((e: any) => ({ ...e, category: c.category })));
const examById = (id: string) => ALL_EXAMS.find((e: any) => e.id === id);

export function LabPage() {
  const { user } = useAuth();
  const { lang } = useLang();
  const L = DICT[lang] || DICT.fr;
  const cid = () => localStorage.getItem("divinelink.clinicId") || undefined;
  const inClinic = (c?: string) => { const a = cid(); return !a || !c || String(c) === String(a); };
  const [patients, setPatients] = useState<Patient[]>([]);
  const [rows, setRows] = useState<LabResult[]>([]);
  const [view, setView] = useState<"results" | "reagents">("results");
  const [tab, setTab] = useState("ordered");
  const [search, setSearch] = useState("");
  const [orderOpen, setOrderOpen] = useState(false);
  const [orderPatient, setOrderPatient] = useState("");
  const [orderExam, setOrderExam] = useState("");
  const [result, setResult] = useState<LabResult | null>(null);
  const [values, setValues] = useState<Record<string, string>>({});
  const [notes, setNotes] = useState("");
  const [busy, setBusy] = useState(false);

  const load = async () => {
    setPatients((await decryptPatients(await db.patients.toArray())).filter(p => !p.deleted && inClinic(p.clinicId)));
    setRows((await db.labResults.toArray()).filter(r => !r.deleted && inClinic(r.clinicId)).sort((a, b) => (b.orderedAt || "").localeCompare(a.orderedAt || "")));
  };
  useEffect(() => { load(); }, []);

  const pName = (id: number) => { const p = patients.find(x => x.id === id); return p ? `${p.firstName} ${p.lastName}` : "—"; };
  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return rows.filter(r => (tab === "all" || r.status === tab) && (!q || pName(r.patientId).toLowerCase().includes(q) || r.examName.toLowerCase().includes(q)));
  }, [rows, tab, search, patients]);
  const orderedCount = rows.filter(r => r.status === "ordered").length;
  const doneCount = rows.filter(r => r.status === "completed").length;

  const createOrder = async () => {
    if (!orderPatient || !orderExam) { toast.error(L.needBoth); return; }
    const exam = examById(orderExam); if (!exam) return;
    const now = new Date().toISOString();
    await db.labResults.add({
      uid: (globalThis.crypto?.randomUUID?.() || String(Date.now())),
      patientId: Number(orderPatient), examId: exam.id, examName: exam.name, category: exam.category,
      status: "ordered", orderedBy: user?.name, orderedAt: now, clinicId: cid(), createdAt: now, updatedAt: now,
    } as any);
    toast.success(L.created);
    setOrderOpen(false); setOrderPatient(""); setOrderExam(""); await load();
  };

  const openResult = (r: LabResult) => { setResult(r); setValues(r.values || {}); setNotes(r.notes || ""); };
  const saveResult = async () => {
    if (!result) return;
    setBusy(true);
    try {
      const now = new Date().toISOString();
      await db.labResults.update(result.id!, { values, notes, status: "completed", resultBy: user?.name, resultAt: now, updatedAt: now });
      toast.success(L.saved);
      setResult(null); await load();
    } finally { setBusy(false); }
  };
  const remove = async (r: LabResult) => { await db.labResults.update(r.id!, { deleted: true, updatedAt: new Date().toISOString() }); await load(); };

  const statusBadge = (s: string) => s === "completed"
    ? <Badge className="bg-green-100 text-green-700 border-green-300">{L.doneBadge}</Badge>
    : <Badge className="bg-yellow-100 text-yellow-700 border-yellow-300">{L.pendingBadge}</Badge>;

  const resultExam = result ? examById(result.examId) : null;
  const abnormal = (f: any, v: string) => {
    if (f.isSelect || f.isText || !v || (f.min === 0 && f.max === 0)) return false;
    const n = parseFloat(v); return !isNaN(n) && (n < f.min || n > f.max);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <h1 className="text-xl font-bold flex items-center gap-2"><FlaskConical className="w-5 h-5" /> {L.title}</h1>
        {view === "results" && <Button size="sm" onClick={() => setOrderOpen(true)} className="gap-1"><Plus className="w-4 h-4" /> {L.newOrder}</Button>}
      </div>

      <div className="flex gap-2">
        <Button size="sm" variant={view === "results" ? "default" : "outline"} className="gap-1" onClick={() => setView("results")}><FlaskConical className="w-4 h-4" /> {L.analyses}</Button>
        <Button size="sm" variant={view === "reagents" ? "default" : "outline"} className="gap-1" onClick={() => setView("reagents")}><FlaskRound className="w-4 h-4" /> {L.reagents}</Button>
      </div>

      {view === "reagents" && <LabReagents />}

      {view === "results" && (<>
      <div className="grid grid-cols-2 gap-3">
        <Card><CardContent className="p-3"><p className="text-xs text-muted-foreground">{L.pending}</p><p className="text-2xl font-bold text-yellow-600">{orderedCount}</p></CardContent></Card>
        <Card><CardContent className="p-3"><p className="text-xs text-muted-foreground">{L.done}</p><p className="text-2xl font-bold text-green-600">{doneCount}</p></CardContent></Card>
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="grid grid-cols-3 w-full">
          <TabsTrigger value="ordered">{L.pending}</TabsTrigger>
          <TabsTrigger value="completed">{L.done}</TabsTrigger>
          <TabsTrigger value="all">{L.all}</TabsTrigger>
        </TabsList>
      </Tabs>

      <div className="relative">
        <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
        <Input className="pl-9" placeholder={L.searchPh} value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      <div className="space-y-2">
        {filtered.length === 0 && <p className="text-sm text-muted-foreground">{L.none}</p>}
        {filtered.map(r => (
          <Card key={r.id}><CardContent className="p-3 flex items-center gap-3">
            <FlaskConical className="w-4 h-4 text-primary flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="font-medium truncate">{r.examName}</p>
              <p className="text-xs text-muted-foreground">{pName(r.patientId)} · {new Date(r.orderedAt).toLocaleDateString(lang === "en" ? "en-GB" : "fr-FR")}</p>
            </div>
            {statusBadge(r.status)}
            {r.status === "ordered"
              ? <Button size="sm" className="h-8 gap-1 text-xs" onClick={() => openResult(r)}><FileText className="w-3.5 h-3.5" /> {L.enter}</Button>
              : <Button size="sm" variant="outline" className="h-8 gap-1 text-xs" onClick={() => openResult(r)}>{L.view}</Button>}
            <Button size="icon" variant="ghost" className="h-8 w-8 text-destructive" onClick={() => remove(r)}><Trash2 className="w-3.5 h-3.5" /></Button>
          </CardContent></Card>
        ))}
      </div>
      </>)}

      {/* New order */}
      <Dialog open={orderOpen} onOpenChange={setOrderOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>{L.newOrderTitle}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><label className="text-sm">{L.patient}</label>
              <Select value={orderPatient} onValueChange={setOrderPatient}>
                <SelectTrigger><SelectValue placeholder={L.choose} /></SelectTrigger>
                <SelectContent>{patients.map(p => <SelectItem key={p.id} value={String(p.id)}>{p.firstName} {p.lastName}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><label className="text-sm">{L.exam}</label>
              <Select value={orderExam} onValueChange={setOrderExam}>
                <SelectTrigger><SelectValue placeholder={L.chooseExam} /></SelectTrigger>
                <SelectContent className="max-h-72">
                  {LAB_CATALOGUE.map((c: any) => (
                    <div key={c.category}>
                      <p className="px-2 py-1 text-[10px] font-bold uppercase text-muted-foreground">{c.category}</p>
                      {c.exams.map((e: any) => <SelectItem key={e.id} value={e.id}>{e.name}</SelectItem>)}
                    </div>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter><Button variant="outline" onClick={() => setOrderOpen(false)}>{L.cancel}</Button><Button onClick={createOrder}>{L.create}</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Enter / view result */}
      <Dialog open={!!result} onOpenChange={v => { if (!v) setResult(null); }}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{result?.examName}</DialogTitle></DialogHeader>
          {result && resultExam && (
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">{pName(result.patientId)}</p>
              {resultExam.fields.map((f: any) => {
                const v = values[f.key] || "";
                const bad = abnormal(f, v);
                return (
                  <div key={f.key} className="flex items-center gap-2">
                    <label className="text-sm flex-1">{f.label}{f.unit ? ` (${f.unit})` : ""}{!f.isSelect && !f.isText && (f.min || f.max) ? <span className="text-[10px] text-muted-foreground ml-1">[{f.min}–{f.max}]</span> : null}</label>
                    {f.isSelect ? (
                      <Select value={v} onValueChange={val => setValues(s => ({ ...s, [f.key]: val }))}>
                        <SelectTrigger className="w-44"><SelectValue placeholder="—" /></SelectTrigger>
                        <SelectContent>{f.options.map((o: string) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
                      </Select>
                    ) : (
                      <Input className={`w-44 ${bad ? "border-red-500 text-red-600 font-semibold" : ""}`} value={v} onChange={e => setValues(s => ({ ...s, [f.key]: e.target.value }))} />
                    )}
                  </div>
                );
              })}
              <Textarea placeholder={L.notes} value={notes} onChange={e => setNotes(e.target.value)} />
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setResult(null)}>{L.close}</Button>
            <Button onClick={saveResult} disabled={busy}>{result?.status === "completed" ? L.update : L.save}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
